package logicline.modeleSemantique;

import java.util.HashSet;
import java.util.Set;

public class Constante extends Formule {
	
	Boolean value;

	public Constante(Boolean b) {
		value = b;
	}
	@Override
	public String toString() {
		return value.toString();
	}

	@Override
	public Set<String> variablesLibres() {
		return new HashSet<>();
	}

	@Override
	public Formule substitue(Substitution s) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean valeur() throws VariableLibreException {
		// TODO Auto-generated method stub
		return false;
	}

}
