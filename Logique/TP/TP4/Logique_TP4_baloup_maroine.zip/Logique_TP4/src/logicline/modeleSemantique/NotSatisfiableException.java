package logicline.modeleSemantique;

public class NotSatisfiableException extends Exception 
{
    public NotSatisfiableException() 
    {
    }
}