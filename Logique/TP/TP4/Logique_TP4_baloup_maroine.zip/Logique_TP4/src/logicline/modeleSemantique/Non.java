package logicline.modeleSemantique;

import java.util.Set;

public class Non extends Formule {
	protected Formule formule;
	
	public Non(Formule f) {
		formule = f;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "(¬"+formule+")";
	}

	@Override
	public Set<String> variablesLibres() {
		return formule.variablesLibres();
	}

	@Override
	public Formule substitue(Substitution s) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean valeur() throws VariableLibreException {
		// TODO Auto-generated method stub
		return false;
	}

}
