package logicline.modeleSemantique;

public class FalseClauseException extends Exception 
{
    public FalseClauseException() 
    {
    }
}