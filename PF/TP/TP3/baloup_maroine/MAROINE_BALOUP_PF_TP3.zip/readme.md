Programmation fonctionnelle TP3
============================

####Binôme
- Maxime MAROINE
- Marc BALOUP


####Contenu
- LSystem.hs
- Tortue.hs
- TortueVolantes.hs

####Statut du travail
- Terminé (100%)

####Difficultés rencontrées
- Avoir des réflexes de programmations fonctionnelle
- Bien cerner le sujet et appliquer correctement les consignes
- Apprendre à mieux se servir de la documentation